# Copyright (c) 2024 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .base_audio_result import BaseAudioResult
from .base_cv_result import BaseCVResult
from .base_result import BaseResult
from .base_ts_result import BaseTSResult
from .base_video_result import BaseVideoResult
from .converter import LatexConverter, MarkdownConverter, WordConverter
from .mixin import (
    Base64Mixin,
    CSVMixin,
    HtmlMixin,
    ImgMixin,
    JsonMixin,
    LatexMixin,
    MarkdownMixin,
    StrMixin,
    VideoMixin,
    WordMixin,
    XlsxMixin,
)

# Copyright (c) 2024 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .pp_ocrv5_mobile_det import PPOCRV5MobileDet
from .pp_ocrv5_server_det import PPOCRV5ServerDet
from .pp_ocrv6_medium_det import PPOCRV6MediumDet
from .pp_ocrv6_small_det import PPOCRV6SmallDet
